package com.example.iot_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
